package com.example.aac.favorite

data class FavoriteItem(
    val label: String,
    val iconResId: Int,
    val docId: String = ""
)

