package com.example.aac.model

data class Book(
    val title: String,
    val author: String,
    val publisher: String,
    val category: String,
    val description: String
)
