package com.example.aac

data class CardItem(
    val iconResId: Int,
    val label: String,
    val type: String = "default"

)
